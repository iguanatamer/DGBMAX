PBEditPack.
-----------

Copyright � 1999 BakSoft-Denmark, Poul Bak.

http://home11.inet.tele.dk/BakSoft/
Mailto: baksoft-denmark@dk2net.dk

-----------------------------------
PBEditPack is a collection of 6 FREEWARE Edit-components for Delphi: PBBinHexEdit, PBDBEdit, PBEdit, PBMaskEdit, PBNumEdit and PBSpinEdit.

Version 2.30.00.00 supports Windows 95, 98 & NT. Supports Default-button-Click.

Full source and Context-sensitive help is included.

The components have been tested with Delphi 3.0, but should work in Delphi 2, 3 and 4.

All components have Alignment and 'mouse-selectall'.
'Mouse-selectall' means that when you set focus using the mouse (and AutoSelect is True), all the text is selected. Next click deselects. That is more or less a 'Windows-standard'. When you set focus using <tab> it is standard, so it is more logical that the mouse works the same way.

PBDBEdit, PBEdit, PBMaskEdit and PBSpinEdit are standard components with Alignment and 'mouse-selectall'.

PBBinHexEdit is a special Edit component for binary and hexadecimal values. NumberFormat sets the display- and editformat (Number, Binary or HexaDecimal). Set and access values by propertys: AsInteger, AsHex and AsBin. (Tip: You can make it invisible, if you you just need the conversions).

PBNumEdit is a special Edit component for numeric values - supporting WYSIWYG editing, floating and fixed decimalpoint. NumberFormat sets the display- and editformat (Standard, Thousands, Scientific and Engineering). You can set max- and minValue. 

Legal stuff:
------------
PBEditPack is Freeware. Use it any way, you like. There are no timelimit or 'nag-screens'. Applications developed using these components are yours alone, Baksoft have no rights to it.

PBEditPack is provided 'as-is' and Baksoft is under no circumstances responsible for any damage, what soever, that it might cause to anyone or anything.

Installation:
-------------
1. Unzip all files to a folder of your choice.
2. Start Delphi (if you haven't done so).
3. If you have unzipped to a folder that is not in the Delphi Searc path, add it: Select 'Tools', 'Environment options...', 'Library' tab, add the full path to the folder to 'Library path'.
4. Select 'Files', 'Open', 'Delphi Package Source' as filetype and browse to the folder, where you have unzipped the files. Select 'PBEditPack.dpk' and 'open'.
5. Click 'Compile' and 'Install'.

Now you have a new Palette-page named 'PB' with the new components.

Install context-sensitive help:
-------------------------------
1. Move or copy 'PBEditPack.hlp', 'PBEditPack.FTS' and 'PBEditPack.cnt' to ..\Delphi 3\Help folder.
2. Doubleclick 'Delphi3.cnt' and 'Microsoft Help Workshop' starts.
   Click 'Index Files', 'add'. Type 'PBEditPack' as Help title and 'PBEditPack.hlp' as Help filename. Click 'Ok'.
3. Include 'PBEditPack.cnt' in the main page (Insert above).
4. Exit 'Microsoft Help Workshop' and save the changes.

Now you have full context-sensitive help for the PBEditPack components.
--------------------------------
I have included a small demo: PBEditPackDemo to show the basics. Load, compile and run.

